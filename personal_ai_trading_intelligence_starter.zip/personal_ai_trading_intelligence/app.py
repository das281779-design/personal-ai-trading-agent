import os
from io import BytesIO
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
from google import genai

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

st.set_page_config(page_title="Personal AI Trading Intelligence", page_icon="🧠", layout="wide")

st.markdown("""
<style>
    .stApp { background: #0b1020; color: #edf2f7; }
    [data-testid="stSidebar"] { background: #111a2e; }
    div[data-testid="stMetric"] { background: #131e33; border: 1px solid #263650; padding: 14px; border-radius: 12px; }
    .note { padding: 12px 14px; border: 1px solid #34445e; border-radius: 10px; background: #121d31; }
</style>
""", unsafe_allow_html=True)

st.title("🧠 Personal AI Trading Intelligence")
st.caption("Multi-market educational research • বাংলা + English • Paper analysis only")

st.warning(
    "শুধু শিক্ষামূলক বিশ্লেষণ। এটি কোনো আর্থিক পরামর্শ নয়। "
    "এই অ্যাপ কোনো ব্রোকারে সংযোগ করে না এবং আসল টাকা দিয়ে ট্রেড করে না। "
    "মার্কেট ডেটা না দিলে লাইভ দাম দেখানোর ভান করবে না।"
)

# Optional single-user access gate. Set ACCESS_PASSWORD in Streamlit Secrets before cloud deployment.
try:
    access_password = st.secrets.get("ACCESS_PASSWORD", "")
except Exception:
    access_password = ""
if access_password:
    entered_password = st.text_input("Personal access password", type="password")
    if entered_password != access_password:
        st.info("অ্যাপ ব্যবহার করতে সঠিক access password দাও।")
        st.stop()
else:
    st.warning("ACCESS_PASSWORD সেট করা নেই। ব্যক্তিগত তথ্য আপলোড কোরো না এবং এই অবস্থায় অ্যাপটি পাবলিকভাবে deploy কোরো না।")

def get_api_key():
    try:
        return st.secrets.get("GEMINI_API_KEY", "") or os.getenv("GEMINI_API_KEY", "")
    except Exception:
        return os.getenv("GEMINI_API_KEY", "")

def ai_answer(prompt, context=""):
    key = get_api_key()
    if not key:
        return "Gemini API key পাওয়া যায়নি। Streamlit Secrets-এ GEMINI_API_KEY যোগ করো।"
    try:
        client = genai.Client(api_key=key)
        model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        response = client.models.generate_content(
            model=model,
            contents=(
                "You are an educational multi-market research assistant. "
                "Reply in Bengali + English when useful. Never promise returns, "
                "never tell the user to place a real trade, and clearly distinguish "
                "facts, assumptions, and uncertainty. If data is missing, say so. "
                "Use uploaded notes only as reference material, not as unquestionable truth.\n\n"
                f"REFERENCE MATERIAL:\n{context[:25000]}\n\n"
                f"USER REQUEST:\n{prompt}"
            )
        )
        return response.text or "AI কোনো টেক্সট ফেরত দেয়নি।"
    except Exception as e:
        return f"Gemini API error: {e}"

def extract_file(upload):
    name = upload.name.lower()
    raw = upload.getvalue()
    if name.endswith(".txt"):
        return raw.decode("utf-8", errors="replace")
    if name.endswith(".csv"):
        df = pd.read_csv(BytesIO(raw))
        return "CSV preview:\n" + df.head(100).to_string(index=False)
    if name.endswith((".xlsx", ".xls")):
        df = pd.read_excel(BytesIO(raw))
        return "Spreadsheet preview:\n" + df.head(100).to_string(index=False)
    if name.endswith(".pdf"):
        if PdfReader is None:
            return "PDF পড়তে pypdf package দরকার।"
        reader = PdfReader(BytesIO(raw))
        return "\n".join((page.extract_text() or "") for page in reader.pages)[:25000]
    if name.endswith(".docx"):
        try:
            from docx import Document
            doc = Document(BytesIO(raw))
            return "\n".join(p.text for p in doc.paragraphs)
        except Exception as e:
            return f"DOCX পড়া যায়নি: {e}"
    return "এই ফাইল ফরম্যাটটি এখন সমর্থিত নয়। PDF, TXT, CSV, XLSX বা DOCX ব্যবহার করো।"

def normalize_columns(df):
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    aliases = {
        "date": ["date", "datetime", "timestamp", "time"],
        "open": ["open", "o"],
        "high": ["high", "h"],
        "low": ["low", "l"],
        "close": ["close", "adj close", "adj_close", "c", "price"],
        "volume": ["volume", "vol", "v"],
    }
    rename = {}
    for target, names in aliases.items():
        for col in df.columns:
            if col in names:
                rename[col] = target
                break
    return df.rename(columns=rename)

def add_indicators(df):
    df = normalize_columns(df)
    if "close" not in df.columns:
        raise ValueError("CSV-তে close বা price নামে কলাম থাকতে হবে।")
    for col in ["open", "high", "low"]:
        if col not in df.columns:
            df[col] = df["close"]
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    df = df.dropna(subset=["close"]).copy()
    df["EMA20"] = df["close"].ewm(span=20, adjust=False).mean()
    df["EMA50"] = df["close"].ewm(span=50, adjust=False).mean()
    delta = df["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, float("nan"))
    df["RSI14"] = 100 - (100 / (1 + rs))
    ema12 = df["close"].ewm(span=12, adjust=False).mean()
    ema26 = df["close"].ewm(span=26, adjust=False).mean()
    df["MACD"] = ema12 - ema26
    df["MACD_SIGNAL"] = df["MACD"].ewm(span=9, adjust=False).mean()
    mid = df["close"].rolling(20).mean()
    std = df["close"].rolling(20).std()
    df["BB_UPPER"] = mid + 2 * std
    df["BB_LOWER"] = mid - 2 * std
    return df

def trend_summary(df):
    last = df.iloc[-1]
    parts = []
    if pd.notna(last["EMA20"]) and pd.notna(last["EMA50"]):
        parts.append("EMA20 above EMA50" if last["EMA20"] > last["EMA50"] else "EMA20 below EMA50")
    if pd.notna(last["RSI14"]):
        parts.append(f"RSI14={last['RSI14']:.1f}")
    if pd.notna(last["MACD"]) and pd.notna(last["MACD_SIGNAL"]):
        parts.append("MACD above signal" if last["MACD"] > last["MACD_SIGNAL"] else "MACD below signal")
    if len(df) < 55:
        parts.append("Limited history: fewer than 55 rows")
    return "; ".join(parts) or "Insufficient indicator data"

if "knowledge" not in st.session_state:
    st.session_state.knowledge = {}
if "analysis_df" not in st.session_state:
    st.session_state.analysis_df = None
if "analysis_name" not in st.session_state:
    st.session_state.analysis_name = "Uploaded dataset"

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Choose section", [
        "Dashboard", "Knowledge Center", "Market Data Analysis",
        "Strategy Backtest", "AI Research Chat"
    ])
    st.divider()
    st.caption("Markets: Stocks • Forex • Crypto • Commodities • Indices")
    st.caption("Data source: user-uploaded files only in this starter version.")

if page == "Dashboard":
    st.subheader("Personal research dashboard")
    c1, c2, c3 = st.columns(3)
    c1.metric("Knowledge files", len(st.session_state.knowledge))
    c2.metric("Market dataset", "Loaded" if st.session_state.analysis_df is not None else "Not loaded")
    c3.metric("Execution mode", "Paper / Educational")
    st.markdown('<div class="note">শুরু করতে Knowledge Center-এ নিজের শিক্ষামূলক নোট আপলোড করো, তারপর Market Data Analysis-এ OHLCV CSV দাও।</div>', unsafe_allow_html=True)
    st.markdown("#### Supported data columns")
    st.code("date, open, high, low, close, volume", language="text")
    st.info("এই সংস্করণে স্বয়ংক্রিয় লাইভ মার্কেট ফিড বা ব্রোকার সংযোগ নেই। নির্ভরযোগ্য ডেটা ফাইল আপলোড করাই ডেটা বিশ্লেষণের ভিত্তি।")

elif page == "Knowledge Center":
    st.subheader("📚 Personal Trading Knowledge Center")
    uploads = st.file_uploader(
        "Upload your educational strategy files",
        type=["pdf", "txt", "csv", "xlsx", "xls", "docx"],
        accept_multiple_files=True
    )
    if uploads:
        for f in uploads:
            try:
                text = extract_file(f)
                st.session_state.knowledge[f.name] = text
                st.success(f"Processed: {f.name} ({len(text)} characters)")
            except Exception as e:
                st.error(f"{f.name}: {e}")
    if st.session_state.knowledge:
        st.markdown("#### Saved in this session")
        for name, content in list(st.session_state.knowledge.items()):
            with st.expander(name):
                st.write(content[:4000] or "No readable text found.")
                if st.button(f"Remove {name}", key=f"remove_{name}"):
                    del st.session_state.knowledge[name]
                    st.rerun()
        if st.button("Summarize my uploaded strategy notes"):
            combined = "\n\n".join(f"FILE: {k}\n{v}" for k, v in st.session_state.knowledge.items())
            with st.spinner("Analyzing uploaded notes..."):
                st.markdown(ai_answer(
                    "Summarize these files. Extract rules, assumptions, indicators, entry/exit concepts, "
                    "risk controls, contradictions, and missing evidence. Do not recommend real trades.",
                    combined
                ))
        st.caption("নোট: এই starter version-এ ফাইলগুলো বর্তমান session-এর memory-তে থাকে; স্থায়ী private database নেই।")
    else:
        st.info("এখনও কোনো ফাইল আপলোড করা হয়নি।")

elif page == "Market Data Analysis":
    st.subheader("📈 Multi-market technical analysis")
    up = st.file_uploader("Upload historical OHLCV CSV", type=["csv"], key="market_csv")
    if up:
        try:
            raw = pd.read_csv(up)
            df = add_indicators(raw)
            st.session_state.analysis_df = df
            st.session_state.analysis_name = up.name
            st.success(f"Loaded {len(df)} rows from {up.name}")
        except Exception as e:
            st.error(f"Could not read dataset: {e}")
    df = st.session_state.analysis_df
    if df is not None and len(df):
        last = df.iloc[-1]
        a, b, c, d = st.columns(4)
        a.metric("Latest close", f"{last['close']:.4g}")
        b.metric("RSI (14)", "—" if pd.isna(last["RSI14"]) else f"{last['RSI14']:.1f}")
        c.metric("EMA20", f"{last['EMA20']:.4g}")
        d.metric("EMA50", f"{last['EMA50']:.4g}")
        fig = go.Figure()
        x = df["date"] if "date" in df.columns else df.index
        fig.add_trace(go.Scatter(x=x, y=df["close"], name="Close"))
        fig.add_trace(go.Scatter(x=x, y=df["EMA20"], name="EMA20"))
        fig.add_trace(go.Scatter(x=x, y=df["EMA50"], name="EMA50"))
        fig.update_layout(template="plotly_dark", height=450, title="Close and moving averages")
        st.plotly_chart(fig, use_container_width=True)
        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(x=x, y=df["RSI14"], name="RSI14"))
        fig2.add_hline(y=70, line_dash="dash")
        fig2.add_hline(y=30, line_dash="dash")
        fig2.update_layout(template="plotly_dark", height=260, title="RSI (14)")
        st.plotly_chart(fig2, use_container_width=True)
        st.markdown("#### Indicator interpretation (not a trade instruction)")
        st.write(trend_summary(df))
        st.dataframe(df.tail(20), use_container_width=True)
        if st.button("Ask AI to explain this dataset"):
            context = "Dataset: " + st.session_state.analysis_name + "\n" + trend_summary(df) + "\n" + df.tail(30).to_string(index=False)
            with st.spinner("Explaining indicators..."):
                st.markdown(ai_answer(
                    "Explain the current indicator readings in Bengali + English. Discuss bullish, bearish, "
                    "and neutral evidence, data limitations, and why waiting may be appropriate. "
                    "Do not tell me to place a real trade.",
                    context
                ))
    else:
        st.info("প্রথমে একটি CSV আপলোড করো। Sample CSV project folder-এ দেওয়া আছে।")

elif page == "Strategy Backtest":
    st.subheader("🧪 Educational strategy backtest")
    df = st.session_state.analysis_df
    if df is None or len(df) < 60:
        st.info("Backtest-এর জন্য অন্তত 60 rows historical CSV দরকার। Market Data Analysis-এ CSV আপলোড করো।")
    else:
        fee_pct = st.number_input("Assumed total cost per position change (%)", min_value=0.0, max_value=2.0, value=0.10, step=0.01)
        fast_n = st.slider("Fast EMA", 5, 30, 10)
        slow_n = st.slider("Slow EMA", 20, 100, 30)
        if fast_n >= slow_n:
            st.error("Fast EMA অবশ্যই Slow EMA-এর চেয়ে ছোট হতে হবে।")
        else:
            bt = df.copy()
            bt["fast"] = bt["close"].ewm(span=fast_n, adjust=False).mean()
            bt["slow"] = bt["close"].ewm(span=slow_n, adjust=False).mean()
            # Shift signal by one bar to avoid using the current bar's close before it exists.
            bt["position"] = (bt["fast"] > bt["slow"]).astype(int).shift(1).fillna(0)
            bt["market_return"] = bt["close"].pct_change().fillna(0)
            bt["turnover"] = bt["position"].diff().abs().fillna(bt["position"])
            bt["strategy_return"] = bt["position"] * bt["market_return"] - (bt["turnover"] * fee_pct / 100)
            bt["equity"] = (1 + bt["strategy_return"]).cumprod()
            bt["buy_hold"] = (1 + bt["market_return"]).cumprod()
            peak = bt["equity"].cummax()
            drawdown = bt["equity"] / peak - 1
            total = (bt["equity"].iloc[-1] - 1) * 100
            maxdd = drawdown.min() * 100
            m1, m2, m3 = st.columns(3)
            m1.metric("Hypothetical strategy return", f"{total:.2f}%")
            m2.metric("Maximum drawdown", f"{maxdd:.2f}%")
            m3.metric("Bars tested", len(bt))
            chart = go.Figure()
            x = bt["date"] if "date" in bt.columns else bt.index
            chart.add_trace(go.Scatter(x=x, y=bt["equity"], name="EMA strategy"))
            chart.add_trace(go.Scatter(x=x, y=bt["buy_hold"], name="Buy-and-hold reference"))
            chart.update_layout(template="plotly_dark", height=400, title="Hypothetical equity curves (starting at 1.0)")
            st.plotly_chart(chart, use_container_width=True)
            st.caption("এটি কেবল একটি সরল উদাহরণ কৌশল; এটি তোমার নিজস্ব strategy নয়। Slippage, taxes, liquidity, survivorship bias এবং real execution differences ফল বদলে দিতে পারে। অতীতের ফল ভবিষ্যৎ ফলের নিশ্চয়তা নয়।")
            st.download_button("Download backtest CSV", bt.to_csv(index=False).encode("utf-8"), "educational_backtest.csv", "text/csv")

elif page == "AI Research Chat":
    st.subheader("💬 Ask your Personal AI Research Assistant")
    question = st.text_area("তোমার প্রশ্ন লিখো / Ask your research question", height=120,
        placeholder="আমার আপলোড করা strategy notes এবং এই dataset-এর indicator অনুযায়ী trend কী? What evidence is missing?")
    if st.button("Analyze with AI", type="primary", disabled=not question.strip()):
        knowledge = "\n\n".join(f"FILE: {k}\n{v}" for k, v in st.session_state.knowledge.items())
        market_context = ""
        if st.session_state.analysis_df is not None:
            d = st.session_state.analysis_df
            market_context = f"Dataset: {st.session_state.analysis_name}\n{trend_summary(d)}\nRecent rows:\n{d.tail(20).to_string(index=False)}"
        with st.spinner("Researching..."):
            st.markdown(ai_answer(question, knowledge + "\n\n" + market_context))
    st.caption("AI-এর উত্তর ভুল বা অসম্পূর্ণ হতে পারে। গুরুত্বপূর্ণ সিদ্ধান্তের আগে স্বাধীনভাবে যাচাই করো।")

st.divider()
st.caption("Personal AI Trading Intelligence • Educational prototype • No real-money execution")
