# Personal AI Trading Intelligence Agent

A Bengali + English educational research prototype for uploaded multi-market datasets and personal strategy notes.

## Included
- Dashboard
- Knowledge Center: PDF, TXT, CSV, XLSX, DOCX text extraction
- Technical indicators: RSI, MACD, EMA20/50, Bollinger Bands
- Historical CSV analysis
- A simple delayed-signal EMA crossover educational backtest
- Gemini-powered research chat using uploaded notes and current dataset context
- CSV export

## Important limitations
- No broker connection, real-money order placement, or automated trading.
- No built-in live market feed. Upload a data file from a source you are authorized to use.
- Uploaded knowledge is stored in Streamlit session memory in this starter version, not a durable private database.
- This is not a financial-advice product. Indicator readings can be wrong or misleading.
- Do not upload passwords, account numbers, private credentials, or sensitive financial documents.
- Streamlit Community Cloud apps are reachable by URL. Do not deploy sensitive personal files there. For private use, run locally or add proper authentication and private storage before deployment.

## Run locally
1. Install Python 3.10+.
2. In this folder run:
   `pip install -r requirements.txt`
3. Create `.streamlit/secrets.toml`:
   ```toml
   GEMINI_API_KEY = "PASTE_YOUR_KEY_HERE"
ACCESS_PASSWORD = "CHOOSE_A_LONG_PRIVATE_PASSWORD"
   ```
4. Start:
   `streamlit run app.py`

Get a Gemini API key from https://aistudio.google.com/app/apikey
Keep it secret. Never paste it into app.py or commit secrets.toml to GitHub.

## Deploy
1. Create a private GitHub repository and upload app.py, requirements.txt, and README.md.
2. Open https://share.streamlit.io/ and connect GitHub.
3. Select the repository and `app.py`.
4. In Advanced settings / Secrets, add:
   `GEMINI_API_KEY = "your-key"`
   `ACCESS_PASSWORD = "your-long-private-password"`
5. Deploy.

Check current Streamlit Community Cloud limits and privacy settings before uploading private material. Free quotas and model availability can change.

## CSV format
Required:
- `close` (or `price`)

Recommended:
- `date, open, high, low, close, volume`

Use historical data you have permission to use. Dates and prices must be valid and sorted oldest to newest.
